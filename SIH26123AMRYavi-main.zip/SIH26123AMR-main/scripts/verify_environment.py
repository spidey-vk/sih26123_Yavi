#!/usr/bin/env python3
"""Automated, reproducible environment verification script for NRDAS AMR Fleet."""

import os
import shutil
import subprocess
import sys


def check_command(cmd_list, name):
    executable = cmd_list[0]
    if not shutil.which(executable):
        print(f"[FAIL] {name}: executable '{executable}' not found on PATH.")
        return False
    try:
        res = subprocess.run(cmd_list, capture_output=True, text=True, check=True)
        out = res.stdout.strip().splitlines()[0] if res.stdout.strip() else "OK"
        print(f"[PASS] {name}: {out}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"[FAIL] {name}: command failed with exit code {e.returncode}: {e.stderr.strip()}")
        return False


def main():
    print("=" * 60)
    print(" NRDAS AMR Fleet — M0 Environment Verification")
    print("=" * 60)

    success = True

    # 1. OS & Python
    py_ver = sys.version.split()[0]
    print(f"[PASS] Python Interpreter: {py_ver}")
    if sys.version_info < (3, 10):
        print("[FAIL] Python >= 3.10 required.")
        success = False

    # 2. ROS 2 Distro
    ros_distro = os.environ.get("ROS_DISTRO", "")
    if ros_distro.lower() == "jazzy":
        print(f"[PASS] ROS 2 Distribution: {ros_distro}")
    else:
        print(f"[FAIL] Expected ROS_DISTRO=jazzy, found '{ros_distro}'")
        success = False

    # 3. Build & Compiler Tools
    success &= check_command(["g++", "--version"], "C++ Compiler (GCC)")
    success &= check_command(["cmake", "--version"], "CMake")
    success &= check_command(["colcon", "--help"], "Colcon Build Tool")
    success &= check_command(["git", "--version"], "Git VCS")

    # 4. Gazebo Sim
    success &= check_command(["gz", "sim", "--versions"], "Gazebo Harmonic")

    # 5. Zenoh Check
    try:
        res = subprocess.run(
            ["ros2", "pkg", "xml", "rmw_zenoh_cpp"],
            capture_output=True,
            text=True,
            check=True,
        )
        if "0.2" in res.stdout:
            print("[PASS] ROS 2 Middleware: rmw_zenoh_cpp found")
        else:
            print(f"[WARN] rmw_zenoh_cpp found with output: {res.stdout.strip()[:60]}")
    except Exception as e:
        print(f"[FAIL] rmw_zenoh_cpp check failed: {e}")
        success = False

    print("=" * 60)
    if success:
        print("RESULT: ALL M0 ENVIRONMENT CHECKS PASSED")
        sys.exit(0)
    else:
        print("RESULT: M0 ENVIRONMENT CHECK FAILED")
        sys.exit(1)


if __name__ == "__main__":
    main()
