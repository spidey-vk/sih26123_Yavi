# NRDAS Mathematical and Algorithmic Specification: Comprehensive System Notes

> **Document Classification**: Core Engineering Specification & Mathematical Notes  
> **System**: NRDAS (Network-Resilient Decentralized Autonomous Systems) AMR Coordination Architecture  
> **Target Environment**: ROS 2 Jazzy Jalisco, Gazebo Sim 8.11.0 (Harmonic), DART Physics Engine, Python 3.12  
> **Scope**: Exhaustive derivation, mathematical formulation, algorithmic descriptions, complexity analysis, and implementation parameters for all subsystems from start to end.

---

## Table of Contents
1. [Nomenclature, Coordinate Frames & Kinematic Constraints](#1-nomenclature-coordinate-frames--kinematic-constraints)
2. [Decentralized Task Allocation: CBBA / ACBBA Formulation](#2-decentralized-task-allocation-cbba--acbba-formulation)
3. [Task Sequencing & Bundle Execution Heuristics](#3-task-sequencing--bundle-execution-heuristics)
4. [Rolling-Horizon Collision Resolution (RHCR) 4D Spatio-Temporal Planning](#4-rolling-horizon-collision-resolution-rhcr-4d-spatio-temporal-planning)
5. [Space-Time Corridor Reservations & Conflict Detection](#5-space-time-corridor-reservations--conflict-detection)
6. [Priority Inheritance Backtracking (PIBT) Local Coordinator](#6-priority-inheritance-backtracking-pibt-local-coordinator)
7. [Wait-For-Graph (WFG) Deadlock Detection & Deterministic Recovery](#7-wait-for-graph-wfg-deadlock-detection--deterministic-recovery)
8. [Level 1 Reactive LiDAR Safety Controller (Absolute Authority)](#8-level-1-reactive-lidar-safety-controller-absolute-authority)
9. [Communication Impairment & Stale-State Eviction Dynamics](#9-communication-impairment--stale-state-eviction-dynamics)
10. [Adaptive Compute Policy Engine: Dynamic Hysteresis & Throttling](#10-adaptive-compute-policy-engine-dynamic-hysteresis--throttling)
11. [Task Accounting, Fleet Metrics & Verification Invariants](#11-task-accounting-fleet-metrics--verification-invariants)
12. [End-to-End Implementation Parameter Reference Table](#12-end-to-end-implementation-parameter-reference-table)
13. [Milestone 4: Compound Fault Resilience & Invariant Formulation](#13-milestone-4-compound-fault-resilience--invariant-formulation)

---

## 1. Nomenclature, Coordinate Frames & Kinematic Constraints

### 1.1 Spatial and Temporal Discretization
The operating environment is a 2D warehouse floor bounded by $\Omega = [0, X_{\text{max}}] \times [0, Y_{\text{max}}] \subset \mathbb{R}^2$.
- **Continuous World Coordinates**: $\mathbf{x} = (x, y) \in \Omega$, with robot pose $\mathbf{q} = (x, y, \theta) \in SE(2)$, where $\theta \in (-\pi, \pi]$ represents yaw heading.
- **Discrete 2D Grid World**: Discretized into uniform square cells with grid resolution $\delta_{\text{grid}} = 0.50\,\text{m}$.
  $$i = \left\lfloor \frac{x}{\delta_{\text{grid}}} \right\rfloor, \quad j = \left\lfloor \frac{y}{\delta_{\text{grid}}} \right\rfloor$$
  $$\mathbf{x}_{\text{world}}(i, j) = \left( (i + 0.5)\delta_{\text{grid}}, \, (j + 0.5)\delta_{\text{grid}} \right)$$
- **Time Discretization**: Continuous time $t \in \mathbb{R}^+$ is discretized for planning into uniform timesteps:
  $$t_k = k \cdot \Delta t, \quad \Delta t = 0.50\,\text{s}$$

### 1.2 Robot Physical Footprint & Spatial Safety Envelope
Each AMR is modeled as a differential-drive rectangular mobile robot:
- **Chassis Dimensions**: Length $L = 0.60\,\text{m}$, Width $W = 0.40\,\text{m}$, Height $H = 0.25\,\text{m}$.
- **Bounding Bumper Radius**: $r_{\text{robot}} = \frac{1}{2} \sqrt{L^2 + W^2} = \frac{1}{2} \sqrt{0.36 + 0.16} = \frac{\sqrt{0.52}}{2} \approx 0.36\,\text{m}$ (conservatively modeled as $r_{\text{robot}} = 0.30\,\text{m}$ for the circular core).
- **Safety Margin Inflation**: $\delta_{\text{safe}} = 0.15\,\text{m}$.
- **Critical Stopping Threshold**:
  $$d_{\text{crit}} = 0.35\,\text{m}$$
- **Minimum Inter-Robot Clearance**:
  $$D_{\text{clear}} = 2 \cdot r_{\text{robot}} + \delta_{\text{safe}} = 2(0.30) + 0.15 = 0.75\,\text{m}$$
- **Warning Slowdown Distance**:
  $$d_{\text{warn}} = 0.80\,\text{m}$$

### 1.3 Kinematic Equations of Differential Drive
Each robot $i$ follows unicycle non-holonomic kinematics:
$$\begin{bmatrix} \dot{x}_i \\ \dot{y}_i \\ \dot{\theta}_i \end{bmatrix} = \begin{bmatrix} \cos\theta_i & 0 \\ \sin\theta_i & 0 \\ 0 & 1 \end{bmatrix} \begin{bmatrix} v_i \\ \omega_i \end{bmatrix}$$
Subject to velocity and acceleration saturation bounds:
$$|v_i| \le v_{\text{max}} = 1.00\,\text{m/s}, \quad v_{\text{nom}} = 0.80\,\text{m/s}$$
$$|\omega_i| \le \omega_{\text{max}} = 1.00\,\text{rad/s}, \quad \omega_{\text{nom}} = 0.80\,\text{rad/s}$$
$$\left|\frac{dv_i}{dt}\right| \le a_{\text{max}} = 0.80\,\text{m/s}^2, \quad \left(\frac{dv_i}{dt}\right)_{\text{decel}} \le a_{\text{decel}} = 1.20\,\text{m/s}^2$$
$$\left|\frac{d\omega_i}{dt}\right| \le \alpha_{\text{max}} = 1.50\,\text{rad/s}^2$$

---

## 2. Decentralized Task Allocation: CBBA / ACBBA Formulation

Task allocation is governed by the Consensus-Based Bundle Algorithm (CBBA), executed locally on each robot without a central coordinator.

### 2.1 Agent State Vectors
For each robot $i \in \{1, \dots, N\}$ and task catalog $\mathcal{T} = \{1, \dots, M\}$:
1. **Task Bundle** $b_i = (b_{i,1}, b_{i,2}, \dots, b_{i,|b_i|}) \in \mathcal{T}^{|b_i|}$, where $|b_i| \le L_{\text{max}} = 8$ is the maximum bundle capacity.
2. **Path Waypoint Sequence** $p_i$: The corresponding ordered physical locations $(x, y)$ that robot $i$ must visit to execute bundle $b_i$.
3. **Winning Bid Table** $\mathbf{y}_i \in \mathbb{R}^M$: $y_{ij}$ represents robot $i$'s current belief of the highest bid placed for task $j$.
4. **Winning Agent Table** $\mathbf{z}_i \in \{1, \dots, N, \emptyset\}^M$: $z_{ij}$ represents robot $i$'s current belief of which robot holds task $j$.
5. **Information Timestamp Table** $\mathbf{s}_i \in \mathbb{R}^N$: $s_{ik}$ is the timestamp of the last message received from peer $k$.

### 2.2 Phase 1: Bundle Construction & Marginal Score Computation
Each robot greedily evaluates unallocated candidate tasks $j \in \mathcal{T} \setminus b_i$:

#### Base Priority Reward
Each task $j$ carries priority $P_j \in \{1, 2, 3, 4\}$ ($\text{LOW}=1, \text{NORMAL}=2, \text{HIGH}=3, \text{CRITICAL}=4$):
$$U_{\text{base}}(j) = w_p \cdot P_j, \quad w_p = 10.0$$

#### Cumulative Travel Distance
For candidate insertion position $m \in \{m_{\text{locked}}, \dots, |b_i|\}$ in bundle $b_i$:
$$\text{cand\_bundle} = (b_{i,1}, \dots, b_{i,m}, j, b_{i,m+1}, \dots, b_{i,|b_i|})$$
The cumulative distance from the robot's current pose $\mathbf{x}_i(t)$ through all predecessors up to task $j$'s dropoff is:
$$\text{cum\_dist}(m) = \sum_{k=1}^m \left( \|\mathbf{x}_{\text{dropoff}, k-1} - \mathbf{x}_{\text{pickup}, k}\|_2 + \|\mathbf{x}_{\text{pickup}, k} - \mathbf{x}_{\text{dropoff}, k}\|_2 \right)$$
where $\mathbf{x}_{\text{dropoff}, 0} = \mathbf{x}_i(t)$.

#### Travel & Late Cost Functions
$$C_{\text{travel}}(m) = w_d \cdot \text{cum\_dist}(m), \quad w_d = 1.0$$
$$\text{est\_arrival}(m) = t_{\text{curr}} + \frac{\text{cum\_dist}(m)}{v_{\text{nom}}}$$
$$C_{\text{late}}(m) = \begin{cases} w_{\text{late}} \cdot (\text{est\_arrival}(m) - D_j) & \text{if } D_j > 0 \land \text{est\_arrival}(m) > D_j \\ 0 & \text{otherwise} \end{cases}, \quad w_{\text{late}} = 2.0$$

#### Net Marginal Utility with Geometric Discounting
The marginal utility of task $j$ inserted at position $m$ is:
$$U_{\text{net}}(j, m) = U_{\text{base}}(j) - C_{\text{travel}}(m) - C_{\text{late}}(m)$$
Applying geometric temporal discounting to favor immediate tasks:
$$c_{ij}(m) = \left(\gamma^{|b_i|}\right) \cdot \max\left(0.01, \, U_{\text{net}}(j, m)\right), \quad \gamma = 0.95$$

The optimal insertion position $m^*$ and maximum marginal utility $c_{ij}$ are:
$$c_{ij} = \max_{m \ge m_{\text{locked}}} c_{ij}(m), \quad m^* = \arg\max_{m \ge m_{\text{locked}}} c_{ij}(m)$$

#### Insertion Rule
Task $j$ is inserted into bundle $b_i$ at position $m^*$ if:
$$c_{ij} > y_{ij} + \epsilon, \quad \epsilon = 10^{-4}$$
Upon insertion, robot $i$ updates its local belief:
$$z_{ij} \leftarrow i, \quad y_{ij} \leftarrow c_{ij}$$

### 2.3 Phase 2: Consensus & Conflict Resolution
Robots periodically broadcast their bid vectors $(\mathbf{y}_i, \mathbf{z}_i, \mathbf{s}_i)$ over peer-to-peer ROS 2 gossip topics (`/{robot_id}/cbba_bid`).
Upon receiving an incoming bid packet from neighbor $k$, agent $i$ updates its belief for every task $j$ according to the definitive 11-rule consensus matrix:

| Case | Local State ($z_{ij}$) | Peer State ($z_{kj}$) | Condition | Action Taken by Agent $i$ |
| :---: | :---: | :---: | :---: | :--- |
| **1** | $i$ | $k$ | $y_{kj} > y_{ij}$ | **Update**: $z_{ij} \leftarrow k, \, y_{ij} \leftarrow y_{kj}$ (Outbid) |
| **2** | $i$ | $k$ | $y_{kj} \le y_{ij}$ | **Leave**: Retain current ownership |
| **3** | $i$ | $m \ne i, k$ | $y_{kj} > y_{ij} \land s_{km} > s_{im}$ | **Update**: $z_{ij} \leftarrow m, \, y_{ij} \leftarrow y_{kj}$ |
| **4** | $i$ | $m \ne i, k$ | $y_{kj} \le y_{ij} \land s_{km} > s_{im}$ | **Leave**: Local bid is superior |
| **5** | $k$ | $k$ | $s_{kk} > s_{ik}$ | **Update**: Peer refreshed its bid |
| **6** | $k$ | $m \ne i, k$ | $s_{km} > s_{im}$ | **Update**: $z_{ij} \leftarrow m, \, y_{ij} \leftarrow y_{kj}$ |
| **7** | $m \ne i, k$ | $m$ | $s_{km} > s_{im}$ | **Update**: Newer info on third party |
| **8** | $m \ne i, k$ | $k$ | $y_{kj} > y_{ij}$ | **Update**: Peer outbid third party |
| **9** | $m \ne i, k$ | $n \ne i, k, m$ | $s_{kn} > s_{in} \land y_{kj} > y_{ij}$ | **Update**: Newer information |
| **10** | $m \ne i, k$ | $\emptyset$ | $s_{km} > s_{im}$ | **Reset**: $z_{ij} \leftarrow \emptyset, \, y_{ij} \leftarrow 0$ |
| **11** | $\emptyset$ | any | $y_{kj} > 0$ | **Update**: Claim task info |

#### Deterministic Lexicographical Tie-Breaking
When bids are identical within precision tolerance $|y_{ij} - y_{kj}| \le \epsilon$:
$$\text{Winner} = \begin{cases} \text{Agent } i & \text{if } y_{ij} - y_{kj} > \epsilon \\ \text{Agent } k & \text{if } y_{kj} - y_{ij} > \epsilon \\ \text{lexicographical}(\text{ID}_i < \text{ID}_k) & \text{if } |y_{ij} - y_{kj}| \le \epsilon \end{cases}$$

#### Bundle Cascade Pruning Rule
If task $j$ at index $\bar{m}$ in bundle $b_i$ is outbid and surrendered:
$$b_i \leftarrow (b_{i,1}, b_{i,2}, \dots, b_{i,\bar{m}-1})$$
For all vacated downstream tasks $k \in \{b_{i,\bar{m}}, \dots, b_{i,|b_i|}\}$:
$$z_{ik} \leftarrow \emptyset, \quad y_{ik} \leftarrow 0$$
This preserves bundle ordering optimality and avoids phantom sub-routes.

### 2.4 Convergence Metric & Execution Gate
A robot's bundle is mathematically converged when:
$$\text{is\_converged}(i) \iff \forall j \in b_i, \quad z_{ij} = i \quad \land \quad \forall k \in \mathcal{N}_i, \quad s_{ik} \ge t_{\text{last\_bid\_change}}$$
Motion planning execution commits **only** to tasks in converged bundles.

---

## 3. Task Sequencing & Bundle Execution Heuristics

Once a robot achieves bundle convergence, `TaskSequencer` orders the execution sequence using one of four deterministic strategies:

### 3.1 PRIORITY_FIRST (Default Operational Heuristic)
Tasks are sorted by descending priority, with distance to robot as secondary tie-breaker:
$$\mathcal{K}_{\text{pri}}(j) = \Big( -P_j, \, \text{round}\big(\|\mathbf{x}_{\text{pickup}, j} - \mathbf{x}_{\text{robot}}\|_2, 3\big), \, \text{task\_id}_j \Big)$$
$$b_i^* = \text{sort}\left(b_i, \, \text{key} = \mathcal{K}_{\text{pri}}\right)$$

### 3.2 SHORTEST_PATH_FIRST (Greedy TSP Routing)
Minimizes total deadhead travel distance via sequential nearest neighbor:
$$\text{Given current anchor pose } \mathbf{x}_{\text{anchor}}:$$
$$j^* = \arg\min_{j \in b_{\text{remaining}}} \Big( \|\mathbf{x}_{\text{pickup}, j} - \mathbf{x}_{\text{anchor}}\|_2, \, -P_j, \, \text{task\_id}_j \Big)$$
$$\mathbf{x}_{\text{anchor}} \leftarrow \mathbf{x}_{\text{dropoff}, j^*}, \quad b_{\text{remaining}} \leftarrow b_{\text{remaining}} \setminus \{j^*\}$$

### 3.3 DEADLINE_FIRST (Earliest Deadline First — EDF)
Prioritizes tight delivery windows:
$$\mathcal{K}_{\text{dl}}(j) = \Big( D_j, \, -P_j, \, \text{task\_id}_j \Big)$$

### 3.4 In-Progress Preservation Invariant
If a robot is actively executing an in-progress task ($t_{\text{active}}$ in phase `TRANSIT_TO_PICKUP` or `TRANSIT_TO_DROPOFF`), dynamic mid-mission bundle re-auctioning freezes index $m_{\text{locked}}$:
$$m_{\text{locked}} = \text{active\_task\_idx} + 1$$
$$b_i^* = (b_{i, 1}, \dots, b_{i, \text{active\_task\_idx}}) \oplus \text{Sequence}\left(b_{i, \text{new}}\right)$$
Active tasks **never abort or reverse** due to mid-mission auctions.

---

## 4. Rolling-Horizon Collision Resolution (RHCR) 4D Spatio-Temporal Planning

### 4.1 4D State Space & Graph Formulation
The configuration space is discretized into spatio-temporal nodes:
$$\mathbf{s} = (i, j, \theta, k) \in \mathcal{C}_{4D} = \mathbb{Z} \times \mathbb{Z} \times \Theta \times \mathbb{N}$$
where $(i, j)$ is the grid cell, $\theta \in \{0, \frac{\pi}{2}, \pi, \frac{3\pi}{2}\}$ represents discrete orientation, and $k$ represents discrete timestep $t = k \cdot \Delta t$.

### 4.2 Spatio-Temporal A* Cost Formulation
The path search evaluates:
$$f(n) = g(n) + h(n)$$

#### Path Cost $g(n)$
$$g(n) = g(\text{parent}) + \Delta g(n)$$
$$\Delta g(n) = \Delta t_{\text{step}} + \alpha_{\text{rot}} \cdot |\Delta \theta| + \beta_{\text{wait}} \cdot \mathbb{I}_{\text{wait}}$$
where:
- $\Delta t_{\text{step}} = 1.0$ (uniform grid step cost)
- $\alpha_{\text{rot}} = 0.20$ (turn penalty discouraging excessive pivoting)
- $\beta_{\text{wait}} = 1.50$ (wait penalty discouraging indefinite stopping)

#### Admissible Heuristic $h(n)$
To guarantee admissibility and optimality, $h(n)$ combines Manhattan distance and minimal angular deflection:
$$h(n) = \frac{\|(i_n, j_n) - (i_{\text{goal}}, j_{\text{goal}})\|_1 \cdot \delta_{\text{grid}}}{v_{\text{max}}} + \alpha_{\text{rot}} \cdot \min\left(|\theta_n - \theta_{\text{goal}}|, \, 2\pi - |\theta_n - \theta_{\text{goal}}|\right)$$

### 4.3 Horizon Truncation & Prefix Execution
Given full path $\Pi_{\text{full}} = (\mathbf{x}_0, \mathbf{x}_1, \dots, \mathbf{x}_{K})$ computed to the active subgoal:
1. **Planning Horizon Lookahead ($h = 10$ steps $\equiv 5.0\,\text{s}$)**:
   $$\Pi_{\text{horizon}} = \Pi_{\text{full}}[0 : \min(K, h+1)]$$
2. **Execution Window Prefix ($w = 4$ steps $\equiv 2.0\,\text{s}$)**:
   $$\Pi_{\text{exec}} = \Pi_{\text{full}}[0 : \min(K, w+1)]$$

The differential-drive controller executes only $\Pi_{\text{exec}}$. When $w$ steps are exhausted, the robot replans.

### 4.4 Replanning Trigger Conditions
Replanning is triggered if and only if:
$$\text{Trigger} \iff \begin{cases} 
\|\mathbf{x}_{\text{robot}} - \mathbf{x}_{\text{subgoal}}\|_2 \le \epsilon_{\text{goal}} = 0.35\,\text{m} & \text{(Subgoal Arrived)} \\ 
\text{steps\_executed} \ge w = 4 & \text{(Window Exhausted)} \\ 
\text{active\_waypoint\_idx} \ge |\Pi_{\text{exec}}| & \text{(Prefix Completed)} \\ 
t - t_{\text{last\_progress}} > 3.0\,\text{s} & \text{(Progress Timeout)} 
\end{cases}$$

---

## 5. Space-Time Corridor Reservations & Conflict Detection

### 5.1 Reservation Table Mathematics
Each robot maintains a local `ReservationTable` containing 4D space-time bounding intervals:
$$R_i = \left\{ \big(x_k, y_k, t_{k, \text{start}}, t_{k, \text{end}}, \text{prio}\big) \right\}$$
where:
$$t_{k, \text{start}} = k \cdot \Delta t, \quad t_{k, \text{end}} = (k + 1) \cdot \Delta t + \tau_{\text{buffer}}, \quad \tau_{\text{buffer}} = 0.20\,\text{s}$$

### 5.2 Dynamic Forward Headway Sizing
To guarantee collision-free corridor stopping under differential-drive braking, each robot reserves forward headway cells along its velocity vector:
$$d_{\text{headway}}(v) = v \cdot t_{\text{reaction}} + \frac{v^2}{2 \cdot a_{\text{decel}}}$$
For nominal speed $v_{\text{nom}} = 0.80\,\text{m/s}$, reaction latency $t_{\text{reaction}} = 0.20\,\text{s}$, and deceleration $a_{\text{decel}} = 1.20\,\text{m/s}^2$:
$$d_{\text{headway}} = (0.80)(0.20) + \frac{0.64}{2(1.20)} = 0.160 + 0.267 = 0.427\,\text{m}$$
In terms of discrete grid cells ($\delta_{\text{grid}} = 0.50\,\text{m}$):
$$N_{\text{headway}} = \left\lceil \frac{d_{\text{headway}}}{\delta_{\text{grid}}} \right\rceil = 1 \text{ forward cell (inflated to 2 cells in narrow corridors)}.$$

### 5.3 Formal Conflict Conditions
A conflict between Robot $A$ and Robot $B$ occurs if any of the three spatio-temporal invariants is breached:
1. **Vertex / Co-occupancy Conflict**:
   $$\exists t \in [t_{\text{start}}, t_{\text{end}}] \quad \text{s.t.} \quad \|\mathbf{x}_A(t) - \mathbf{x}_B(t)\|_2 < D_{\text{clear}} = 0.75\,\text{m}$$
2. **Edge / Head-on Swap Conflict**:
   $$\exists t \quad \text{s.t.} \quad \left( \|\mathbf{x}_A(t) - \mathbf{x}_B(t+1)\|_2 < \delta_{\text{grid}} \right) \land \left( \|\mathbf{x}_B(t) - \mathbf{x}_A(t+1)\|_2 < \delta_{\text{grid}} \right)$$
3. **Following / Tailgating Conflict**:
   $$\mathbf{x}_A(t+1) = \mathbf{x}_B(t) \quad \land \quad v_A > v_B \quad \land \quad \|\mathbf{x}_A(t) - \mathbf{x}_B(t)\|_2 < d_{\text{headway}}$$

---

## 6. Priority Inheritance Backtracking (PIBT) Local Coordinator

When two robots project overlapping space-time reservations in the immediate next timestep ($t + \Delta t$), PIBT resolves contention locally without centralized replanning.

### 6.1 Priority Vector Formulation
Each robot's dynamic priority tuple is strictly ordered:
$$\mathcal{P}_i(t) = \Big( P_{\text{task}, i}, \, -d_{\text{subgoal}, i}(t), \, -\text{NumericID}(i) \Big)$$
where:
- $P_{\text{task}, i} \in \{1, 2, 3, 4\}$: Higher task priority strictly dominates.
- $-d_{\text{subgoal}, i}$: Closer robots have higher priority (minimizes transit stalling).
- $-\text{NumericID}(i)$: Deterministic tie-breaker (lower numeric ID wins).

### 6.2 Priority Inheritance Mechanism
If Robot $A$ targets cell $C = \mathbf{x}_A(t+1)$ currently occupied by Robot $B$:
1. If $\mathcal{P}_A > \mathcal{P}_B$:
   - Robot $B$ temporarily inherits priority: $\mathcal{P}_B \leftarrow \mathcal{P}_A$.
   - Robot $B$ evaluates its 4-connected neighbors $\mathcal{N}(C)$ to vacate cell $C$.
   - If an empty adjacent cell $C' \in \mathcal{N}(C)$ is unreserved, Robot $B$ steps to $C'$.
2. If Robot $B$ is completely constrained (all neighbors blocked or occupied by higher-priority agents):
   - Priority inheritance backtracks to Robot $A$.
   - Robot $A$ yields: $\mathbf{x}_A(t+1) \leftarrow \mathbf{x}_A(t)$ (executes a 1-step wait action).

---

## 7. Wait-For-Graph (WFG) Deadlock Detection & Deterministic Recovery

In multi-robot warehouse intersections and chokepoints, cyclic waiting dependencies can form (Robot $A$ waits for $B$, $B$ waits for $C$, and $C$ waits for $A$).

### 7.1 Directed Graph Representation
The fleet state is represented as a directed graph $G = (V, E)$:
- **Vertices** $V = \{\text{amr}_0, \text{amr}_1, \dots, \text{amr}_{N-1}\}$.
- **Directed Edges** $(u \to v) \in E \iff$ Robot $u$ is waiting for cell $C$ currently occupied or reserved by Robot $v$.

### 7.2 Tarjan's Strongly Connected Components (SCC) Cycle Detection
Evaluated every $1.0\,\text{s}$ across all active reservations:
- Each vertex $u$ maintains discovery index $\text{dfn}[u]$ and lowest reachable index $\text{low}[u]$:
  $$\text{low}[u] = \min \begin{cases} \text{dfn}[u] \\ \text{dfn}[w], & (u, w) \in E \land w \in \text{stack} \\ \text{low}[w], & (u, w) \in E \land w \notin \text{stack} \end{cases}$$
- **Deadlock Condition**: A deadlock exists if any strongly connected component contains two or more vertices:
  $$\exists \text{SCC}_k \subset V \quad \text{s.t.} \quad |\text{SCC}_k| \ge 2$$

### 7.3 Deterministic Evading Robot Election
When cycle $\mathcal{C} = \{r_1, r_2, \dots, r_k\}$ is detected, the evading robot $r^*$ is selected deterministically:
$$r^* = \arg\max_{r \in \mathcal{C}} \text{NumericID}(r) \quad \text{subject to} \quad \mathcal{P}_r = \min_{u \in \mathcal{C}} \mathcal{P}_u$$
The lowest-priority robot (breaking ties with highest numeric robot ID) is elected.

### 7.4 Evasion Maneuver Kinematics
Robot $r^*$ immediately:
1. Relinquishes all active reservations in $\Pi_{\text{exec}}$.
2. Commands reverse linear velocity $v = -0.25\,\text{m/s}$ for distance $d_{\text{retreat}} = 1.50\,\text{m}$ along its reverse heading $-\theta$.
3. Backs into the nearest warehouse passing alcove or charging bay:
   $$\mathbf{x}_{\text{evade}} = \mathbf{x}_{r^*} - 1.50 \begin{bmatrix} \cos\theta_{r^*} \\ \sin\theta_{r^*} \end{bmatrix}$$
4. Re-enters the planning state after a dwell pause of $\tau_{\text{yield}} = 3.0\,\text{s}$.

---

## 8. Level 1 Reactive LiDAR Safety Controller (Absolute Authority)

The Reactive LiDAR Safety Controller sits at the lowest level of the autonomy architecture and holds **absolute preemption authority** over all higher-level software commands.

### 8.1 10 Hz Independent Execution Loop
The controller runs on an isolated $10\,\text{Hz}$ ROS 2 timer ($100\,\text{ms}$ period) directly reading raw `sensor_msgs/msg/LaserScan` messages:
$$\mathcal{S} = \left\{ (r_k, \phi_k) \mid k = 1, \dots, K \right\}$$
where $r_k$ is the measured distance and $\phi_k$ is the beam bearing relative to the robot's forward heading ($x$-axis).

### 8.2 Forward Arc Obstacle Filtering
Measurements are filtered to evaluate the forward collision cone:
$$\phi_k \in \left[ -\frac{\theta_{\text{fov}}}{2}, \, +\frac{\theta_{\text{fov}}}{2} \right], \quad \theta_{\text{fov}} = 90^\circ = \frac{\pi}{2}\,\text{rad}$$
The minimum forward obstacle distance is:
$$d_{\text{min}} = \min \left\{ r_k \mid r_k > r_{\text{min\_valid}} \land |\phi_k| \le \frac{\pi}{4} \right\}$$

### 8.3 Piecewise Linear Braking & Emergency Stop Formula
Let $v_{\text{plan}}$ and $\omega_{\text{plan}}$ be the commands requested by RHCR. The commanded velocities $(v_{\text{cmd}}, \omega_{\text{cmd}})$ transmitted to the wheel drivers are:

$$v_{\text{cmd}} = \begin{cases} 
0.00 & \text{if } d_{\text{min}} \le d_{\text{crit}} = 0.35\,\text{m} \quad \text{\bf (EMERGENCY STOP)} \\ 
v_{\text{plan}} \cdot \left(\frac{d_{\text{min}} - d_{\text{crit}}}{d_{\text{warn}} - d_{\text{crit}}}\right) & \text{if } d_{\text{crit}} < d_{\text{min}} \le d_{\text{warn}} = 0.80\,\text{m} \quad \text{\bf (PROPORTIONAL BRAKE)} \\ 
v_{\text{plan}} & \text{if } d_{\text{min}} > d_{\text{warn}} = 0.80\,\text{m} \quad \text{\bf (CLEAR)} 
\end{cases}$$

$$\omega_{\text{cmd}} = \begin{cases} 
0.00 & \text{if } d_{\text{min}} \le d_{\text{crit}} = 0.35\,\text{m} \\ 
\omega_{\text{plan}} \cdot \left(\frac{d_{\text{min}} - d_{\text{crit}}}{d_{\text{warn}} - d_{\text{crit}}}\right) & \text{if } d_{\text{crit}} < d_{\text{min}} \le d_{\text{warn}} \\ 
\omega_{\text{plan}} & \text{if } d_{\text{min}} > d_{\text{warn}} 
\end{cases}$$

### 8.4 Independence Invariant
The safety braking loop is:
- Completely decoupled from A* planning threads.
- Completely decoupled from ROS 2 DDS network connectivity.
- Completely decoupled from CBBA auction convergence states.
- Guaranteed to stop the robot within $d_{\text{stop}} \le \frac{v_{\text{max}}^2}{2 a_{\text{decel}}} = \frac{1.0}{2(1.2)} \approx 0.42\,\text{m}$, preventing physical contact in all evaluated Gazebo scenarios.

---

## 9. Communication Impairment & Stale-State Eviction Dynamics

Real-world wireless channels in warehouse environments are modeled by the active impairment node `CommunicationModelNode`.

### 9.1 Network Impairment Profiles
For any outgoing inter-robot message $M$:

| Parameter | `NORMAL` | `LOSS_LOW` | `LOSS_HIGH` |
| :--- | :---: | :---: | :---: |
| **Packet Loss Ratio ($p_{\text{loss}}$)** | $0.00$ | $0.10$ ($10\%$) | $0.35$ ($35\%$) |
| **Mean Transmission Delay ($\mu_{\text{delay}}$)** | $0.0\,\text{ms}$ | $20.0\,\text{ms}$ | $80.0\,\text{ms}$ |
| **Jitter Standard Deviation ($\sigma_{\text{jitter}}$)** | $0.0\,\text{ms}$ | $5.0\,\text{ms}$ | $20.0\,\text{ms}$ |

#### Stochastic Drop Mechanism
$$X \sim \text{Uniform}(0, 1)$$
$$\text{Action} = \begin{cases} \text{DROP} & \text{if } X < p_{\text{loss}} \\ \text{DELAY } \tau & \text{if } X \ge p_{\text{loss}} \end{cases}$$
where $\tau \sim \max\left(0, \, \mathcal{N}(\mu_{\text{delay}}, \sigma_{\text{jitter}}^2)\right)$.

### 9.2 Stale-State Time-To-Live (TTL) Pruning
When peer packets are dropped, a robot might permanently hold phantom reservations for a disconnected neighbor, leading to false deadlocks.
Each robot's `StaleStateManager` tracks heartbeat timestamps:
$$\Delta t_{\text{peer}}(j) = t_{\text{now}} - t_{\text{last\_heartbeat}}(j)$$
The TTL eviction rule enforces:
$$\text{If } \Delta t_{\text{peer}}(j) > T_{\text{TTL}} = 1.50\,\text{s} \implies \text{Purge all } R_j \text{ from } \text{ReservationTable}$$
Reclaiming stale corridor cells allows healthy AMRs to route around stalled or disconnected peers without human intervention.

---

## 10. Adaptive Compute Policy Engine: Dynamic Hysteresis & Throttling

The `AdaptiveComputePolicy` runs as an onboard governor that monitors CPU load, network health, and spatial contention to modulate planning parameters dynamically.

### 10.1 Discrete Compute Modes & Parameters
Three operational modes are defined:

$$\begin{array}{|l|c|c|c|c|c|}
\hline
\text{\bf Mode} & f_{\text{replan}} \text{ (Hz)} & \text{Horizon } h & \text{Window } w & f_{\text{cbba}} \text{ (Hz)} & \text{Budget } \tau_{\text{plan}} \text{ (ms)} \\
\hline
\text{\bf LOW} & 1.0 & 6 & 6 & 2.0 & 20.0 \\
\text{\bf NORMAL} & 2.0 & 10 & 4 & 5.0 & 50.0 \\
\text{\bf HIGH} & 4.0 & 14 & 2 & 10.0 & 100.0 \\
\hline
\end{array}$$

### 10.2 Host Telemetry Smoothing
CPU utilization is sampled via `psutil` and smoothed via exponential moving average:
$$\bar{u}_{\text{CPU}}(t) = \alpha_{\text{smooth}} \cdot u_{\text{CPU}}(t) + (1 - \alpha_{\text{smooth}}) \cdot \bar{u}_{\text{CPU}}(t-1), \quad \alpha_{\text{smooth}} = 0.30$$

### 10.3 Priority-Ordered Evaluation State Machine
Transitions evaluate signals in strict order of severity:
1. **Network Degradation (Triggers LOW)**:
   $$\bar{t}_{\text{stale}} \ge 1.50\,\text{s} \quad \lor \quad p_{\text{loss}} \ge 0.15 \quad \lor \quad \tau_{\text{plan}} \ge 15.0\,\text{ms}$$
2. **Compute Resource Pressure (Triggers LOW)**:
   $$\bar{u}_{\text{CPU}}(t) \ge 85.0\%$$
3. **Recovery to NORMAL (from LOW)**:
   $$\bar{t}_{\text{stale}} \le 0.80\,\text{s} \quad \land \quad p_{\text{loss}} \le 0.05 \quad \land \quad \bar{u}_{\text{CPU}}(t) \le 65.0\%$$
4. **Traffic Contention (Triggers HIGH from NORMAL)**:
   $$N_{\text{conflicts\_in\_window}} \ge 2 \quad \land \quad \bar{u}_{\text{CPU}}(t) < 70.0\%$$
5. **Recovery to NORMAL (from HIGH)**:
   $$N_{\text{conflicts\_in\_window}} == 0 \quad \lor \quad \bar{u}_{\text{CPU}}(t) \ge 75.0\%$$

### 10.4 Anti-Oscillation Safeguards
To prevent mode chatter:
1. **Minimum Dwell Time**:
   $$t_{\text{now}} - t_{\text{last\_transition}} \ge T_{\text{dwell}} = 3.00\,\text{s}$$
2. **Consecutive Confirmation Samples**:
   A candidate mode transition is committed only after $K = 3$ consecutive affirmative evaluation cycles.
3. **Fail-Safe Fallback**:
   If telemetry becomes null or times out ($t_{\text{now}} - t_{\text{telemetry}} > 5.0\,\text{s}$), the policy falls back to `NORMAL`.

---

## 11. Task Accounting, Fleet Metrics & Verification Invariants

### 11.1 Conservation of Tasks Invariant
Let $\mathcal{S} = \{\text{Pending}, \text{Assigned}, \text{InProgress}, \text{Completed}, \text{Cancelled}, \text{Failed}\}$.
For all simulation epochs $t \in [0, T_{\text{final}}]$:
$$\sum_{S \in \mathcal{S}} |\mathcal{T}_S(t)| = N_{\text{total}}$$
Zero tasks may be duplicated, orphaned, or leaked across states.

### 11.2 Fleet Throughput & Makespan
- **Fleet Mission Makespan**:
  $$T_{\text{make}} = \max_{j \in \mathcal{T}_{\text{completed}}} t_{\text{completion}}(j) - \min_{j \in \mathcal{T}} t_{\text{injection}}(j)$$
- **Average Mission Throughput**:
  $$\Theta = \frac{|\mathcal{T}_{\text{completed}}|}{T_{\text{horizon}}} \quad \left[\frac{\text{tasks}}{\text{second}}\right]$$
- **Service Level / Deadline Compliance (SLC)**:
  $$\text{SLC} = \frac{1}{|\mathcal{T}_{\text{completed}}|} \sum_{j \in \mathcal{T}_{\text{completed}}} \mathbb{I}\Big( t_{\text{completion}}(j) \le D_j \Big)$$

### 11.3 Safety Metric Verification Invariants
During any valid benchmark execution:
1. **Zero Physical Collisions**:
   $$\sum_{k=1}^K \mathbb{I}_{\text{Gazebo\_Contact_Sensor}} = 0$$
2. **Zero Chassis Overlap Violations**:
   $$\forall i \ne j, \quad \min_t \|\mathbf{x}_i(t) - \mathbf{x}_j(t)\|_2 \ge 2 \cdot r_{\text{robot}} = 0.60\,\text{m}$$
3. **Zero Unrecovered Deadlocks**:
   $$\forall \text{cycle } \mathcal{C}, \quad t_{\text{recovery}}(\mathcal{C}) \le T_{\text{deadlock\_max}} = 10.0\,\text{s}$$

---

## 12. End-to-End Implementation Parameter Reference Table

| Subsystem | Parameter Name | Canonical Value | Physical / Algorithmic Unit | Code File Location |
| :--- | :--- | :---: | :---: | :--- |
| **Grid Environment** | `grid_resolution` | `0.50` | meters ($\text{m}$) | `rh_planner.py` |
| **Grid Environment** | `world_bounds` | `[0.0, 32.0]` | meters ($\text{m}$) | `warehouse_m9_v2.sdf` |
| **AMR Physical** | `robot_radius` | `0.30` | meters ($\text{m}$) | `conflict_detector.py` |
| **AMR Physical** | `chassis_length` | `0.60` | meters ($\text{m}$) | `warehouse_m9_v2.sdf` |
| **AMR Physical** | `chassis_width` | `0.40` | meters ($\text{m}$) | `warehouse_m9_v2.sdf` |
| **AMR Kinematics** | `nominal_speed` ($v_{\text{nom}}$) | `0.80` | $\text{m/s}$ | `fleet_params.yaml` |
| **AMR Kinematics** | `max_speed` ($v_{\text{max}}$) | `1.00` | $\text{m/s}$ | `fleet_params.yaml` |
| **AMR Kinematics** | `max_accel` ($a_{\text{max}}$) | `0.80` | $\text{m/s}^2$ | `fleet_params.yaml` |
| **AMR Kinematics** | `max_decel` ($a_{\text{decel}}$) | `1.20` | $\text{m/s}^2$ | `fleet_params.yaml` |
| **AMR Kinematics** | `max_angular_vel` ($\omega_{\text{max}}$) | `1.00` | $\text{rad/s}$ | `fleet_params.yaml` |
| **CBBA Allocation** | `bundle_capacity` ($L_{\text{max}}$) | `8` | tasks | `cbba_agent.py` |
| **CBBA Allocation** | `discount_factor` ($\gamma$) | `0.95` | dimensionless $\in (0, 1]$ | `cbba_agent.py` |
| **CBBA Allocation** | `weight_priority` ($w_p$) | `10.0` | score units / priority | `cbba_agent.py` |
| **CBBA Allocation** | `weight_distance` ($w_d$) | `1.0` | score units / meter | `cbba_agent.py` |
| **CBBA Allocation** | `weight_late` ($w_{\text{late}}$) | `2.0` | score units / second | `cbba_agent.py` |
| **CBBA Allocation** | `bid_epsilon` ($\epsilon$) | `1e-4` | score units | `cbba_agent.py` |
| **RHCR Planning** | `horizon_steps` ($h$) | `10` | discrete steps ($5.0\,\text{s}$) | `rh_planner.py` |
| **RHCR Planning** | `execution_window` ($w$) | `4` | discrete steps ($2.0\,\text{s}$) | `rh_planner.py` |
| **RHCR Planning** | `replan_rate` ($f_{\text{replan}}$) | `2.0` | $\text{Hz}$ | `rh_planner.py` |
| **RHCR Planning** | `goal_tolerance_m` ($\epsilon_{\text{goal}}$) | `0.35` | meters ($\text{m}$) | `rh_planner.py` |
| **RHCR Planning** | `planning_budget_ms` ($\tau_{\text{plan}}$) | `50.0` | milliseconds ($\text{ms}$) | `rh_node.py` |
| **Safety Interlock**| `safety_rate` | `10.0` | $\text{Hz}$ | `rh_node.py` |
| **Safety Interlock**| `critical_stop_threshold` ($d_{\text{crit}}$)| `0.35` | meters ($\text{m}$) | `rh_node.py` |
| **Safety Interlock**| `warning_distance` ($d_{\text{warn}}$) | `0.80` | meters ($\text{m}$) | `rh_node.py` |
| **Safety Interlock**| `laser_fov` ($\theta_{\text{fov}}$) | `90.0` | degrees ($1.57\,\text{rad}$) | `rh_node.py` |
| **Reservations** | `headway_cells` | `2` | grid cells ($1.0\,\text{m}$) | `reservation_table.py` |
| **Reservations** | `ttl_expiration_s` ($T_{\text{TTL}}$) | `1.5` | seconds ($\text{s}$) | `stale_state_manager.py` |
| **Deadlock WFG** | `cycle_eval_rate` | `1.0` | $\text{Hz}$ | `wfg_deadlock.py` |
| **Deadlock WFG** | `evasion_distance` ($d_{\text{retreat}}$)| `1.5` | meters ($\text{m}$) | `deadlock_recovery.py` |
| **Adaptive Compute**| `dwell_time_s` ($T_{\text{dwell}}$) | `3.0` | seconds ($\text{s}$) | `adaptive_compute_policy.py` |
| **Adaptive Compute**| `confirmation_samples` ($K$) | `3` | consecutive samples | `adaptive_compute_policy.py` |
| **Adaptive Compute**| `cpu_high_threshold` | `85.0` | percent ($\%$) | `adaptive_compute_policy.py` |
| **Adaptive Compute**| `cpu_normal_recovery` | `65.0` | percent ($\%$) | `adaptive_compute_policy.py` |
| **Adaptive Compute**| `telemetry_timeout_s` | `5.0` | seconds ($\text{s}$) | `adaptive_compute_policy.py` |

---

## 13. Milestone 4: Compound Fault Resilience & Invariant Formulation

Milestone 4 formalizes the mathematical and algorithmic architecture required for a decentralized AMR fleet to withstand compound, overlapping disturbances across physical, communication, and environmental domains.

### 13.1 Orthogonal 5-Dimensional State Space Formulation

To guarantee deterministic multi-agent state convergence under simultaneous disruptions, each robot $i \in \mathcal{V}$ is characterized by an orthogonal 5-dimensional state tuple:

$$\mathcal{S}_i = \langle s_{health}, s_{comm}, s_{task}, s_{nav}, s_{res} \rangle$$

1. **Health State** $s_{health} \in \{\text{HEALTHY}, \text{COMM\_LOSS}, \text{FAILED}, \text{ESTOP}\}$:
   $$s_{health}(t) = \begin{cases}
   \text{ESTOP} & \text{if } \text{estop\_active}_i(t) \\
   \text{FAILED} & \text{if } t - t_{last\_hb, i} > T_{fail} = 3.5\,\text{s} \\
   \text{COMM\_LOSS} & \text{if } t - t_{last\_hb, i} > T_{comm} = 1.5\,\text{s} \\
   \text{HEALTHY} & \text{otherwise}
   \end{cases}$$

2. **Communication State** $s_{comm} \in \{\text{CONNECTED}, \text{IMPAIRED}, \text{PARTITIONED}, \text{DISCONNECTED}\}$:
   Evaluated over sliding transmission window $W_{pkt} = 20$ packets with measured packet loss $p_{loss} \in [0, 1]$ and peer partition topology matrix $\mathbf{A}_{comm} \in \{0, 1\}^{N \times N}$.

3. **Task Lifecycle State** $s_{task} \in \{\text{STAGED}, \text{PENDING}, \text{ASSIGNED}, \text{IN\_PROGRESS}, \text{COMPLETED}, \text{FAILED}, \text{CANCELLED}\}$:
   Enforces strictly valid state transitions governed by compare-and-swap (CAS) state semantics.

4. **Navigation Mode** $s_{nav} \in \{\text{IDLE}, \text{TRANSIT}, \text{LOCAL\_SAFETY\_HOLD}, \text{SIDESTEP\_RECOVERY}, \text{ESTOP\_HOLD}\}$:
   Dictates local velocity command generation and collision avoidance behavior.

5. **Space-Time Reservation Leases** $s_{res} \subseteq \mathcal{G} \times \mathbb{N}$:
   The set of discrete spacetime coordinates $\{(c, \tau)\}$ held by robot $i$ in the distributed space-time reservation table.

### 13.2 Formal Verification Invariants

The compound resilience system maintains five rigorous system-level mathematical invariants:

#### Invariant $I_1$: Task Mutual Exclusion (Task Uniqueness)
At all physical times $t \ge 0$, no active task $T \in \mathcal{T}_{active}$ can be simultaneously assigned to or executed by more than one AMR:
$$\forall T \in \mathcal{T}_{active}, \quad \sum_{i \in \mathcal{V}} \mathbb{I}[T \in \mathcal{B}_i(t)] \le 1$$
When an AMR crashes ($s_{health} = \text{FAILED}$), its tasks are reclaimed to `PENDING` via an atomic CAS primitive:
$$\text{CAS}(T, \text{expected}=\text{ASSIGNED}(i_{victim}), \text{target}=\text{PENDING})$$
This guarantees that concurrent peer detections produce exactly one successful transition to `PENDING`, completely eliminating double-execution races.

#### Invariant $I_2$: Spacetime Reservation Exclusivity & Dynamic Invalidation
At any discrete spacetime cell $(c, \tau) \in \mathcal{G} \times \mathbb{N}$, at most one robot can possess an active reservation:
$$\forall c \in \mathcal{G}, \forall \tau \in \mathbb{N}, \quad |\{i \in \mathcal{V} : (c, \tau) \in \mathcal{R}_i(t)\}| \le 1$$
Upon corridor blockage or robot failure, the Invalidation Manager instantly purges all conflicting leases:
$$\mathcal{R}(t^+) = \mathcal{R}(t^-) \setminus \{(c, \tau) : c \in \mathcal{O}_{blocked} \lor \text{owner}(c, \tau) \in \mathcal{V}_{failed}\}$$

#### Invariant $I_3$: Local Safety & Clearance Guarantee
Every active AMR must maintain a physical clearance strictly greater than or equal to the minimum safety envelope $r_{robot} = 0.28\,\text{m}$ from any static or dynamic obstacle:
$$\forall i \in \mathcal{V}_{active}, \quad \min_{\mathbf{p}_{obs} \in \mathcal{O}(t)} \|\mathbf{x}_i(t) - \mathbf{p}_{obs}\|_2 \ge r_{robot} = 0.28\,\text{m}$$
If $\min_{\theta \in [-12^\circ, +12^\circ]} d_{LiDAR}(\theta) \le 0.28\,\text{m}$, the reactive safety layer immediately overrides all motor controllers with zero velocity ($v=0, \omega=0$).

#### Invariant $I_4$: Tiered Fault Discrimination
Transient communication loss must never trigger false-positive robot failure reallocations:
$$T_{comm\_loss} = 1.5\,\text{s} < T_{fail\_confirm} = 3.5\,\text{s}$$
During the window $t \in [1.5\,\text{s}, 3.5\,\text{s}]$, the robot transitions to `COMM_LOSS`, preserving its assigned tasks while surviving peers prepare fallback bids without committing reallocation.

#### Invariant $I_5$: Monotonic CAS Partition Reconciliation
During a network partition splitting $\mathcal{V}$ into cliques $\mathcal{V}_A$ and $\mathcal{V}_B$, tasks carry assignment timestamps $t_{assign}$. Upon partition healing at time $t_{heal}$, reconciliation satisfies:
$$\text{Resolve}(T, \mathcal{B}_A, \mathcal{B}_B) = \begin{cases}
\text{Winner}_A & \text{if } t_{assign}(A) > t_{assign}(B) \\
\text{Winner}_B & \text{if } t_{assign}(B) > t_{assign}(A) \\
\min(\text{ID}_A, \text{ID}_B) & \text{if } t_{assign}(A) = t_{assign}(B)
\end{cases}$$
Ensuring monotonic convergence to a single authoritative assignment across merged subgraphs.

### 13.3 Three-Tier Fleet Response Dynamics

When an adversarial compound disruption occurs, the fleet coordinates across three decoupled response layers:

```
Disturbance Injected (Robot Crash + Network Loss + Corridor Blockage)
      │
      ├────────────────────────┬────────────────────────┐
      ▼                        ▼                        ▼
[ Tier 1: Allocation ]   [ Tier 2: Planning ]     [ Tier 3: Safety ]
- Heartbeat debounce     - Invalidate corridor    - 20 Hz LiDAR scan
- CAS task reclamation   - SingleAgentAStar /     - Reactive zero-brake
- CBBA rebidding           RHCR detour search       at d <= 0.28m
- Converged in <=150ms   - Latency <= 0.1ms       - 0 collisions
```

### 13.4 M4 Parameter Specifications

| Parameter | Symbol | Canonical Value | Units | Implementation Location |
| :--- | :---: | :---: | :---: | :--- |
| **Comm Loss Timeout** | $T_{comm}$ | `1.5` | seconds ($\text{s}$) | `resilience_manager.py` |
| **Robot Failure Timeout**| $T_{fail}$ | `3.5` | seconds ($\text{s}$) | `resilience_manager.py` |
| **LiDAR Clearance Threshold** | $d_{clear}$ | `0.28` | meters ($\text{m}$) | `local_safety_monitor.py` |
| **LiDAR Forward Arc** | $\theta_{arc}$ | `24` ($\pm 12$) | degrees ($^\circ$) | `local_safety_monitor.py` |
| **AStar Detour Budget** | $\tau_{detour}$ | `10.0` | milliseconds ($\text{ms}$) | `single_agent_astar.py` |
| **Adversarial Dashboard Port** | $P_{m4}$ | `8081` | TCP Port | `resilience_dashboard.py` |

